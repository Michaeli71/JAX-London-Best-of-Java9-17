package exercises.part4_5;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018/2019 by Michael Inden 
 */
public class Exercise10_Records 
{
	class Square 
	{
		public final double sideLength;
	
		public Square(final double sideLength) 
		{
			this.sideLength = sideLength;
		}
	}
	
	class Circle 
	{
		public final double radius;
	
		public Circle(final double radius) 
		{
			this.radius = radius;
		}
	}
}
