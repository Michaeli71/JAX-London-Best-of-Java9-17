package exercises.part3;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise08_Reader 
{
	public static void main(String[] args) throws IOException 
	{
		var textFile = new File("hello.txt");
		var sr = new StringReader("Hello\nWorld");
				
		try (Writer bfw = null /*TODO*/)
		{
			// TODO
		}

		var sw = new StringWriter();
		try (Reader bfr = null /*TODO*/)			
		{
			// TODO
		}
		System.out.println(sw.toString());
	}
}