package exercises.part1;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise08_Collectors 
{
	public static void main(final String[] args) 
	{
		 exercise8a();
		 exercise8b();
		 exercise8c();
		 exercise8d();
		 exercise8e();
	}
	
	public static void exercise8a()
	{
		final Stream<String> names = Stream.of("Tim", "Tom", "Michael", "Thomas", "Karthikeyan", "Marius");
		final Predicate<String> moreThen5Chars = null; // TODO
		
		final Set<String> longNames = Set.of("TODO");
		System.out.println(longNames);
	}
		
	public static void exercise8b()
	{
		final Stream<String> names = Stream.of("Tim", "Tom", "Michael", "Thomas", "Karthikeyan", "Marius");
		final Predicate<String> moreThen5Chars = null; // TODO
		final Function<String, Character> firstChar = null; // TODO

		final Map<Character, Set<String>> groupedLongNames = Map.of('T', Set.of("TODO"));
		System.out.println(groupedLongNames);
	}
	
	public static void exercise8c()
	{
		final Map<String, Long> personAgeMapping = Map.of("Tim", 47L, "Tom", 12L, "Michael", 47L, "Max", 25L);

		final Function<Map.Entry<String, Long>, Character> firstChar = null; // TODO
		final Predicate<Map.Entry<String, Long>> isAdult = null; // TODO

		final Map<Character, Set<Entry<String, Long>>> filteredPersons = Map.of(); // TODO
		System.out.println(filteredPersons);
	}

	public static void exercise8d()
	{
		final Map<String, Long> personAgeMapping = Map.of("Tim", 47L, "Tom", 12L, "Michael", 47L, "Max", 25L);
				
		final Function<Map.Entry<String, Long>, Character> firstChar = null; // TODO
		final Predicate<Map.Entry<String, Long>> isAdult = null; // TODO

		final Map<Character, Set<String>> filteredPersons = Map.of(); // TODO
		System.out.println(filteredPersons);
	}
	
	public static void exercise8e()
	{
		final Stream<Set<String>> characters = Stream.of(Set.of("a", "c", "e"), 
				                                         Set.of("a", "b"), 
				                                         Set.of("a", "b", "c", "d"),
				                                         Set.of("a", "b", "c", "d", "f")
				                                        );
				
		final Set<String> simpleCharaters = Set.of();
		System.out.println(simpleCharaters);
	}
}
