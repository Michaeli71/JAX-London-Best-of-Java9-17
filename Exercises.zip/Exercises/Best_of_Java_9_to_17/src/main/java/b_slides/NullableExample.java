package b_slides;

import java.util.Optional;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class NullableExample 
{	
	public static void main(final String[] args)
    {
    	final Stream<Customer> customerStream1 = Stream.ofNullable(findCustomer());
        System.out.println(customerStream1.count());
        
        final Stream<Customer> customerStream2 = Stream.ofNullable(findCustomer());
        final Optional<Customer> optFirst = customerStream2.findFirst();
        
        optFirst.ifPresentOrElse(System.out::println,
                                 () -> System.out.println("No element"));
    }

	private static Customer findCustomer() 
	{
		/*
		var names = new ArrayList<String>();
		names.add("NUMA");
		names.add(42);
		*/
		return null;
	}
}