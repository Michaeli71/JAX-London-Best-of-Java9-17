package a_questions;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public record MyPoint(int x, int y) 
{ 
	public static void main(String[] args) {
			    
	    MyPoint point = new MyPoint(17, 19);
	    System.out.println(point);
        System.out.println("" + point.x + ", " + point.y());
        
        
	    MyPoint point2 = new MyPoint(17, 19);
	    if (point.equals(point2))
	    {
	    	System.out.println("GLEICHE WERTEBELEGUNG");
	    }
	    else
	    {
	    	System.out.println("NOT EQUAL");
	    }	    	
	}

	@Override
	public String toString() {
		return "[x: " + x + " / y: " + y + "]";
	}	
	
	/* DO NOT TRY IT AT HOME
	@Override
	public boolean equals(Object other) {
		return false;
	}
	*/
}
