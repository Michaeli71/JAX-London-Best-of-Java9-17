package a_questions;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class TextBlockHelp {

    public static void main(String[] args) {
        String multiLineStringOld = """
            THIS IS
            A MULTI
            LINE STRING
            WITH A BACKSLASH \\
            """;
        System.out.println(multiLineStringOld);
    }

}
