package solutions.part3;

public class Hello
{
    public static void main(String... args)
    {
	    System.out.println("Hello");
	    System.out.println("Hello JAX");
	    System.out.println("Hello");
    }
}