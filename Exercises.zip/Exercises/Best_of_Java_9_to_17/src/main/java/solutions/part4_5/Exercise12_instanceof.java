package solutions.part4_5;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018/2019 by Michael Inden 
 */
public class Exercise12_instanceof 
{
	public static void main(String[] args) 
	{	
		Object obj ="BITTE ein BIT";
		
		if (obj instanceof String str && str.contains("BITTE"))
		{
			System.out.println("It contains the magic word!");		    
		}
	}
}
