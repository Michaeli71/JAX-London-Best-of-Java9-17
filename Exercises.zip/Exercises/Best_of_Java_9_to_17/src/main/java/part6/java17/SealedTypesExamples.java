package part6.java17;

public class SealedTypesExamples {
	sealed interface MathOp permits BaseOp,Add,Sub // <= erlaubte Subtypen
	{
		int calc(int x, int y);
	}

	// Mit non-sealed kann man innerhalb der Vererbungshierarchie Basisklassen
	// bereitstellen
	non-sealed class BaseOp implements MathOp // <= Basisklasse
	// nicht versiegeln
	{
		@Override
		public int calc(int x, int y) {
			return 0;
		}
	}

	final class Add implements MathOp {
		@Override
		public int calc(int x, int y) {
			// TODO Auto-generated method stub
			return 0;
		}
	}

	final class Sub implements MathOp {
		@Override
		public int calc(int x, int y) {
			// TODO Auto-generated method stub
			return 0;
		}
	}
}